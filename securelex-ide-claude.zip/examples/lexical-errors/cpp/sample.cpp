const char *s = "unterminated;
