class Broken { void f( { }
