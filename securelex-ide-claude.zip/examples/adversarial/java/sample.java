class A { String s = "‮"; }
