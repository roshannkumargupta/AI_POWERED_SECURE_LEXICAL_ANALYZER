"""APSLA: AI-Powered Secure Lexical Analyzer core package."""

from __future__ import annotations

__version__ = "0.1.0"
